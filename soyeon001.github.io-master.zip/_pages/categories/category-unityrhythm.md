---
title: "케이디님의 '리듬 게임 만들기' 강의 필기"
layout: archive
permalink: categories/unity-lesson-4
author_profile: true
sidebar_main: true
---

<!-- 공백이 포함되어 있는 카테고리 이름의 경우 site.categories['a b c'] 이런식으로! -->

***

유튜브에 있는 케이디님의 **[유니티 강좌] 리듬 게임** 유튜브 강의를 듣고 정리한 필기입니다. 😀 언제든지 다시 참고할 수 있도록, 지식 공유보단 개인적인 복습을 목적으로 포스팅하였습니다. <br> [🌜 강의 들으러 가기 Click](https://www.youtube.com/watch?v=eLdiOCWPfPc&list=PLUZ5gNInsv_MCnum4bOQRI72LdGkIY3tY&index=2&t=231s)
{: .notice--warning}

{% assign posts = site.categories['Unity Lesson 4'] %}
{% for post in posts %} {% include archive-single2.html type=page.entries_layout %} {% endfor %}